#include "config.h"

char version[] = VERSION;
