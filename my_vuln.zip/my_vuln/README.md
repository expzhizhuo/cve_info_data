# my_vuln
## CVE&CNVD
The IOT vulnerabilities I discovered

Vendors have been contacted ; CVE and CNVD applications have been submitted
